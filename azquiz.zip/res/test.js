var answer;

$(document).ready(function () {
  $(document).on("click", "#test_start", function () {
    $("#start_inner").remove();
    next_set(1);
  });

  $(document).on("click", "#back_button", function () {
    console.log("RESTART");
    location.reload();
  });
  $(document).on("click", "#back_home", function () {
    console.log("RESTART");
    history.back();
  });

  var solution = [
    "011",
    "022",
    "031",
    "042",
    "051",
    "062",
    "071",
    "081",
    "092",
    "102",
  ];

  var score = 0;

  $(document).on("click", ".next_question", function () {
    var current_count = $(this).closest(".question_inner").attr("count");
    var aid = $(this).attr("aid");
    var next_count = parseInt(current_count) + 1;

    console.log(aid);
    if (solution.includes(aid)) {
      score++;
    }
    console.log(score);

    $(".question_inner[count=" + current_count + "]").remove();
    if ($(".question_inner[count=" + next_count + "]").length) {
      next_set(next_count);
    } else {
      $("#progress_inner").remove();

      setTimeout(() => {
        $("#loading_inner").css("display", "flex");
      }, 50);

      anime.timeline().add({
        targets: "#loading_inner",
        translateY: ["120%", 0],
        duration: 1000,
        easing: "easeOutCirc",
        delay: 100,
      });

      $("#result_score").text(score * 10 + "점");

      var desc;
      switch (score) {
        case 0:
          $("#result_img").append("<img src='res/lv0.png'/>");
          break;
        case 1:
        case 2:
          $("#result_img").append("<img src='res/lv1.png'/>");
          break;
        case 3:
        case 4:
          $("#result_img").append("<img src='res/lv2.png'/>");
          break;
        case 5:
        case 6:
          $("#result_img").append("<img src='res/lv3.png'/>");
          break;

        case 7:
        case 8:
          $("#result_img").append("<img src='res/lv4.png'/>");
          break;

        case 9:
        case 10:
          $("#result_img").append("<img src='res/lv5.png'/>");
          break;
      }

      $(document).on("click", "#test_restart", function () {
        console.log("RESTART");
        location.reload();
      });
    }
  });

  function next_set(i) {
    var next_elements = $(".question_inner[count=" + i + "]");

    next_elements.css("display", "flex");
    question_page_animation(i);
  }
});

function money_anime(i) {
  if (i == 1) {
    duration_t = 1000;
    delay_t = 500;
  } else if (i == 2) {
    duration_t = 800;
    delay_t = 0;
  } else {
    duration_t = 900;
    delay_t = 900;
  }
  window.setTimeout(function () {
    anime({
      targets: "#loading_inner #loading_image" + i,
      translateY: -20,
      direction: "alternate",
      loop: true,
      duration: duration_t,
      easing: "easeInOutSine",
    });
  }, delay_t);
}

function question_page_animation(i) {
  anime.timeline().add({
    targets: ".question_inner[count='" + i + "'] .next_question",
    translateX: ["120%", 0],
    duration: 1000,
    easing: "easeOutCirc",
    delay: function (el, i) {
      return i * 100;
    },
  });
}
